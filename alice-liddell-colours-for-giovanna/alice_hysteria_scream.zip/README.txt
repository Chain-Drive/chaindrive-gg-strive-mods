WARNING
-------

Using this mod will globally replace the sound that plays when Giovanna reaches 100% tension, i.e., if this mod is installed, then the sound will play for EVERY colour.